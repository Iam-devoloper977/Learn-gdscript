---
name: Content issue
about: There's a typo or something unclear in some of the app's text.
title: ''
labels: content
assignees: ''

---

**Issue description:**
A clear and concise description of what the issue is.
